# iResultView
### Google Chrome extension for enhanced iRacing result pages

To install this extension, download and extract a ZIP file from the `releases` directory. In Chrome, open the `Extensions` page (`chrome://extensions/`), activate the `Developer mode`, click `Load unpacked`, and select the `iresultview` directory.
